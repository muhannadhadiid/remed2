package remed

fun main() {
    //Buat rumus pertambahan, pengurangan, perkalian, dan pembagian
    val pertambahan = 21+1000
    val pengurangan = 22-300
    val perkalian = 100*1000
    val pembagian = 1000/9000

    println(pertambahan)
    println(pengurangan)
    println(perkalian)
    println(pembagian)
}