package remed

fun main() {
    //print
    //  "Saya lapar sekali, minjem 100 dong buat makan hari ini" 600 kali
    // GUNAKAN RANGE
    val teks = "Saya lapar sekali, minjem 100 dong buat makan hari ini"
    val range = 1..600
    range.forEachIndexed{index,range->
        println("$teks")
    }
}