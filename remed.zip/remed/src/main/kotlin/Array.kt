package remed

fun main() {
    //Buat contoh array min. 20 lalu print
    val namamanusia: Array<String> = arrayOf(
        "islami",
        "hawa",
        "Ilyasa",
        "unais",
        "adam",
        "dyroth",
        "jondon",
        "Mukhtar",
        "eko",
        "Dewi",
        "devi",
        "Rilza",
        "roja",
        "Hendri",
        "putri",
        "silvana",
        "syifa",
        "Aljaa",
        "Hadeng",
        "Sentot",
        "aised",)
    namamanusia.forEachIndexed { index,namamanusia->
        println("$namamanusia")
    }
}