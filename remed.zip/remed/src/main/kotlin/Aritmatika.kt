package remed

fun main() {
    //Buat rumus untuk menghitung aritmatka menggunakan range
    val range =3..39 step 4
    range.forEachIndexed{index,angka->
        println(angka)
    }
}