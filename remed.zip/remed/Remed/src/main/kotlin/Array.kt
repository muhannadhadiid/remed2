package remed

fun main() {
    //Buat contoh array min. 20 lalu print
}