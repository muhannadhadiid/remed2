package remed

fun main() {
    //buat rumus untuk menghitung aritmatika menggunakan range
    //buat rumus untuk menghitung aritmatika menggunakan range
    val range =3..90 Step
    range.forEachIndexed { index,angka ->
        println(angka)
    }
}