
rootProject.name = "Remed"

